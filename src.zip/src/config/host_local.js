const local = "http://localhost:4000/"


module.exports = {
  local
}